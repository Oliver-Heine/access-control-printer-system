package com.dtu.printerservice.exceptions;

public class UnauthorizedException extends RuntimeException {
    public UnauthorizedException(String message) {}
}
