package com.dtu.printerservice.exceptions;

public class InvalidTokenException extends RuntimeException {
    public InvalidTokenException(String message) {}
}
