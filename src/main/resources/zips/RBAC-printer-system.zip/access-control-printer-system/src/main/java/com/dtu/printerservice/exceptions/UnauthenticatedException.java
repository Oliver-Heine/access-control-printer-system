package com.dtu.printerservice.exceptions;

public class UnauthenticatedException extends RuntimeException {
    public UnauthenticatedException(String message) {}
}
